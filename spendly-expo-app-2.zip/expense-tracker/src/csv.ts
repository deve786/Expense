import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { listExpenses } from './db';

const esc = (v: string | number) => {
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export async function exportCsv() {
  const rows = await listExpenses();
  const lines = ['Date,Amount,Category,Payment method,Note,Recurring'];
  for (const r of rows) {
    lines.push([r.date, r.amount, r.cat_name, r.method, r.note, r.recurring_id ? 'yes' : 'no'].map(esc).join(','));
  }
  const file = new File(Paths.cache, `spendly-expenses-${new Date().toISOString().slice(0, 10)}.csv`);
  file.create({ overwrite: true });
  file.write(lines.join('\n'));
  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(file.uri, { mimeType: 'text/csv', dialogTitle: 'Export expenses' });
  }
  return rows.length;
}
